﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Xml;
using System.Windows.Forms;

using Nuane.Net;

namespace TinySSFTP
{
    public partial class MainForm : Form
    {
        int iPort = 990;
        string sPath = string.Empty;

        // generate server keys (in practice, load them from a saved file
        SshKey rsaKey = null;
        SshKey dssKey = null;

        SftpServer server = null;

        public MainForm()
        {
            InitializeComponent();
        }

        void foo()
        {

            // add keys, bindings and users
            server = new SftpServer();
            server.Log = Console.Out;
            server.Keys.Add(rsaKey);
            server.Keys.Add(dssKey);
            server.Bindings.Add(IPAddress.Any, 990);
            server.Users.Add(new SshUser("user01", "us3r01", @"c:\pub\data\sftp\user01"));
            server.Users.Add(new SshUser("user02", "us3r02", @"c:\pub\data\sftp\user02"));

            // start the server
            server.Start();

            Console.WriteLine("Press any key to stop the server.");
            Console.ReadKey();

            // stop the server
            server.Stop();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // generate server keys (in practice, load them from a saved file
            rsaKey = SshKey.Generate(SshKeyAlgorithm.RSA, 1024);
            dssKey = SshKey.Generate(SshKeyAlgorithm.DSS, 1024);

            // StoreUserNodes();
        }

        private void LoadUserList()
        {
            XmlNodeList list = LoadUserNodes();
            foreach (XmlNode n in list)
            {
                string user = n.Attributes["user"].Value;
                string pass = n.Attributes["pass"].Value;
                string path = n.InnerText.Trim();
                server.Users.Add(new SshUser(user, pass, path));
            }
        }


        public string ConfigPath()
        {
            // application path
            string sPath = System.IO.Path.GetDirectoryName(
                System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase);

            sPath = Path.Combine(sPath, "config.xml").Substring(6);
            return sPath;
        }

        private XmlNodeList LoadUserNodes()
        {
            Stream stream = new FileStream(ConfigPath(), FileMode.Open, FileAccess.Read, FileShare.Read);
            XmlDocument doc = new XmlDocument();
            doc.Load(stream);
            stream.Close();

            XmlNodeList list = doc.SelectNodes("settings/users/user");
            return list;
        }

        private void StoreUserNodes()
        {
            XmlAttribute a;
            XmlDocument doc = new XmlDocument();
            XmlNode n = doc.CreateElement("settings");
            doc.AppendChild(n);
            XmlNode c = doc.CreateElement("users");
            n.AppendChild(c);
            n = c;
            c = doc.CreateElement("user");
            n.AppendChild(c);
            a = doc.CreateAttribute("user");
            a.Value = "user01";
            c.Attributes.Append(a);
            a = doc.CreateAttribute("pass");
            a.Value = "us3r01";
            c.Attributes.Append(a);
            c.InnerText = @"c:\pub\data\sftp\user01";
            c = doc.CreateElement("user");
            n.AppendChild(c);
            a = doc.CreateAttribute("user");
            a.Value = "user02";
            c.Attributes.Append(a);
            a = doc.CreateAttribute("pass");
            a.Value = "us3r02";
            c.Attributes.Append(a);
            c.InnerText = @"c:\pub\data\sftp\user02";

            XmlWriterSettings ws = new XmlWriterSettings();
            ws.Indent = true;
            FileStream fs = new FileStream(ConfigPath(),FileMode.Create, FileAccess.Write, FileShare.None);
            XmlWriter w = XmlWriter.Create(fs,ws);
            doc.WriteTo(w);
            w.Flush();
            fs.Flush();
            w.Close();
        }


        private void rbPort22_CheckedChanged(object sender, EventArgs e)
        {
            iPort = 22;
        }

        private void rbPort990_CheckedChanged(object sender, EventArgs e)
        {
            iPort = 990;
        }

        private void btnStartStop_Click(object sender, EventArgs e)
        {
            if (string.Compare( btnStartStop.Text,"start",true) == 0 )
            {
                btnStartStop.Text = "Stop";
                StartServer();
                pictureBox1.Visible = true;
                return;
            }

            server.Stop();
            server.Bindings.Remove(IPAddress.Any, iPort);
            server = null;

            pictureBox1.Visible = false;
            btnStartStop.Text = "Start";
        }

        private void StartServer()
        {
            server = new SftpServer();
            server.Log = Console.Out;
            server.Keys.Add(rsaKey);
            server.Keys.Add(dssKey);
            server.Bindings.Add(IPAddress.Any, iPort);

            LoadUserList();

            server.Start();

            server.Users.Add(new SshUser("u1", "u1", @"c:\u1"));
            //server.Users.Add(new SshUser("user02", "us3r02", @"c:\pub\data\sftp\user02"));
        }

    }
}
